import { Routes, Route } from "react-router-dom";
import CustomerForm from "./components/CustomerForm";

export default function App() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Order Management System</h1>
      <Routes>
        <Route path="/" element={<CustomerForm />} />
      </Routes>
    </div>
  );
}
