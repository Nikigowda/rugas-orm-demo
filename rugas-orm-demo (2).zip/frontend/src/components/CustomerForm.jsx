import { useState } from "react";
import axios from "axios";

export default function CustomerForm() {
  const [customer, setCustomer] = useState({ name: "", address: "", phone: "", email: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/customers", customer);
    alert("Customer added!");
  };

  return (
    <form onSubmit={handleSubmit} className="p-4 border rounded">
      <input type="text" placeholder="Name" value={customer.name} onChange={(e) => setCustomer({ ...customer, name: e.target.value })} className="border p-2 m-2" required />
      <input type="text" placeholder="Address" value={customer.address} onChange={(e) => setCustomer({ ...customer, address: e.target.value })} className="border p-2 m-2" required />
      <input type="text" placeholder="Phone" value={customer.phone} onChange={(e) => setCustomer({ ...customer, phone: e.target.value })} className="border p-2 m-2" required />
      <input type="email" placeholder="Email" value={customer.email} onChange={(e) => setCustomer({ ...customer, email: e.target.value })} className="border p-2 m-2" required />
      <button type="submit" className="bg-blue-500 text-white px-4 py-2">Add Customer</button>
    </form>
  );
}
