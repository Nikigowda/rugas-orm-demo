const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log('MongoDB Connected'))
  .catch(err => console.error('DB Connection Error:', err));

const Customer = mongoose.model('Customer', new mongoose.Schema({
  name: String,
  address: String,
  phone: String,
  email: String,
}));

const Product = mongoose.model('Product', new mongoose.Schema({
  name: String,
  category: String,
  description: String,
  price: Number,
  images: [String],
}));

const Order = mongoose.model('Order', new mongoose.Schema({
  customerId: mongoose.Schema.Types.ObjectId,
  productId: mongoose.Schema.Types.ObjectId,
  status: { type: String, enum: ['placed', 'shipped', 'delivered', 'cancelled'], default: 'placed' }
}));

app.post('/customers', async (req, res) => {
  const customer = new Customer(req.body);
  await customer.save();
  res.json(customer);
});

app.get('/products', async (req, res) => {
  const products = await Product.find();
  res.json(products);
});

app.post('/orders', async (req, res) => {
  const order = new Order(req.body);
  await order.save();
  res.json(order);
});

app.put('/orders/:id/status', async (req, res) => {
  const order = await Order.findByIdAndUpdate(req.params.id, { status: req.body.status }, { new: true });
  res.json(order);
});

app.listen(5000, () => console.log('Server running on port 5000'));
